package com.capgemini.claimRegistration.daoImpl.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.claimRegistration.daoImpl.ClaimQuestionsDaoImpl;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.ClaimQuestions;

public class ClaimQuestionsDaoImplTest {
	ClaimQuestionsDaoImpl claimQuestionDao = null;
	@Before
	public void setUp() throws Exception {
		claimQuestionDao = new ClaimQuestionsDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		claimQuestionDao = null;
	}

	@Test
	public void testGetAllClaimQuestionsNot() {
		List<ClaimQuestions> list = new ArrayList<>() ;
		try {
			list = claimQuestionDao.getAllClaimQuestions(10002l);
			assertNotNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

	@Test
	public void testGetAllClaimQuestions() {
		List<ClaimQuestions> list = new ArrayList<>() ;
		try {
			list = claimQuestionDao.getAllClaimQuestions(10002l);
			assertNull(list);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	@Test
	public void testGetClaimQuestionsNot() {
		try {
			String question = claimQuestionDao.getClaimQuestions(2);
			assertNotNull(question);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}
	
	@Test
	public void testGetClaimQuestions() {
		try {
			String question = claimQuestionDao.getClaimQuestions(2);
			assertNull(question);
		} catch (ClaimException e) {
			
			e.printStackTrace();
		}
	}

}
