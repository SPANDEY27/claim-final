package com.capgemini.claimRegistration.daoImpl.test;

import static org.junit.Assert.*;

import java.util.ArrayList;
import java.util.List;

import org.junit.After;
import org.junit.Before;
import org.junit.Test;

import com.capgemini.claimRegistration.daoImpl.PolicyDetailsDaoImpl;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.PolicyDetails;

public class PolicyDetailsDaoImplTest {

	PolicyDetailsDaoImpl policyDetailsDao = null;
	@Before
	public void setUp() throws Exception {
		policyDetailsDao = new PolicyDetailsDaoImpl();
	}

	@After
	public void tearDown() throws Exception {
		policyDetailsDao = null;
	}

	@Test
	public void testGetPolicyDetailsNot() {
		List<PolicyDetails> list = new ArrayList<>();
		
		try {
			list = policyDetailsDao.getPolicyDetails(10002l);
			assertNotNull(list);
		} catch (ClaimException e) {
		
			e.printStackTrace();
		}
	}
	@Test
	public void testGetPolicyDetails() {
		List<PolicyDetails> list = new ArrayList<>();
		
		try {
			list = policyDetailsDao.getPolicyDetails(10002l);
			assertNull(list);
		} catch (ClaimException e) {
		
			e.printStackTrace();
		}
	}

}
