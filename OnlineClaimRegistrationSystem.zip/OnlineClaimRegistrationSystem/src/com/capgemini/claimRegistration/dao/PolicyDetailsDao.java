package com.capgemini.claimRegistration.dao;

import java.util.List;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.PolicyDetails;

public interface PolicyDetailsDao {

	int insertPolicyDetails(PolicyDetails details)throws ClaimException;

	List<PolicyDetails> getPolicyDetails(long claimNumber)throws ClaimException;

}
