package com.capgemini.claimRegistration.dao;

import java.util.List;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.ClaimQuestions;

public interface ClaimQuestionsDao {

	List<ClaimQuestions> getAllClaimQuestions(long policyNumber)throws ClaimException;

	String getClaimQuestions(int questionId)throws ClaimException;

}
