package com.capgemini.claimRegistration.userRole;

import java.util.ArrayList;
import java.util.InputMismatchException;
import java.util.List;
import java.util.Scanner;

import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.model.Policy;
import com.capgemini.claimRegistration.model.UserRole;
import com.capgemini.claimRegistration.service.ClaimService;
import com.capgemini.claimRegistration.service.PolicyService;
import com.capgemini.claimRegistration.serviceImpl.ClaimServiceImpl;
import com.capgemini.claimRegistration.serviceImpl.PolicyServiceImpl;
import com.capgemini.claimRegistration.ui.Main;
import com.capgemini.claimRegistration.userMethods.ClaimCreation;
import com.capgemini.claimRegistration.userMethods.ProfileCreation;
import com.capgemini.claimRegistration.userMethods.ReportGeneration;
import com.capgemini.claimRegistration.userMethods.ViewClaim;

public class ClaimAdjuster {

	ClaimService service = new ClaimServiceImpl();
	PolicyService policyService = new PolicyServiceImpl();
	Scanner scanner = null;

	public void admin(UserRole user) throws ClaimException {
		boolean adminFlag = false;
		do {
			scanner = new Scanner(System.in);
			System.out.println();
			System.out
					.println("*****************CLAIM ADJUSTER MENU**********************");
			System.out.println();
			System.out.println("1.New Profile Creation");
			System.out.println("2.Claim Creation");
			System.out.println("3.View Claim");
			System.out.println("4.Report Generation");
			System.out.println("5.LOGOUT");
			System.out.println("6.Exit");
			System.out.println("Enter your Choice");
			try {
				int choice = scanner.nextInt();
				switch (choice) {
				case 1:

					ProfileCreation profileCreation = new ProfileCreation();
					profileCreation.createNewProfile(user);
					break;

				case 2:
					System.out.println();
					System.out.printf("%10s %20s %20s %20s", "Policy Number",
							"Account Number", "Policy Premium", "Policy Type");

					List<Policy> policiesList = new ArrayList<Policy>();
					policiesList = policyService.getPolicyList();

					for (Policy policy : policiesList) {
						System.out.println();
						System.out.printf("%10s %20s %20s %20s",
								policy.getPolicyNumber(),
								policy.getAccountNumber(),
								policy.getPolicyPremium(),
								policy.getPolicyType());
					}
					System.out.println();
					boolean policyFlag = false;
					long policyNumber = 0l;
					do {
						scanner = new Scanner(System.in);
						System.out
								.println("Select Policy Number from above list or enter 0 to go back to previous menu:");

						try {
							policyNumber = scanner.nextLong();

							if (policyNumber == 0l) {
								policyFlag = true;
								adminFlag = false;
							} else {

								boolean isPolicyExists = policyService
										.isPolicyExists(policyNumber,
												policiesList);

								if (!isPolicyExists) {
									policyFlag = false;
									System.err
											.println("Given Policy Number does not exist, Select Policy Number from above List");
								} else {
									policyFlag = true;
									boolean checkFlag = policyService
											.isPolicyNumber(policyNumber);
									if (checkFlag == false) {
										ClaimCreation claimCreation = new ClaimCreation();
										claimCreation.createNewClaim(
												policyNumber, user);
									} else {
										System.err
												.println("Claim already created for the policy number:"
														+ policyNumber);

									}
								}
							}

						} catch (InputMismatchException e) {
							policyFlag = false;
							System.err
									.println("Policy Number should be digits only");
						}
					} while (!policyFlag);

					break;

				case 3:
					ViewClaim viewClaim = new ViewClaim();
					viewClaim.showClaim();
					break;

				case 4:
					ReportGeneration report = new ReportGeneration();
					report.generateReport();
					break;

				case 5:
					System.out
							.println("You have successfully logged off from your account");
					adminFlag = true;
					Main.login();
					break;

				case 6:
					System.err.println("Thank you,visit again");
					System.exit(0);
					break;

				default:
					adminFlag = false;
					System.err.println("Choice should be between 1 to 5");
				}

			} catch (InputMismatchException e) {
				adminFlag = false;
				System.err.println("Enter digits only");
			}

		} while (!adminFlag);

	}
}
