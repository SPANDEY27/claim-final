package com.capgemini.claimRegistration.model;

public class Policy {
	private Long policyNumber;
	private Double policyPremium;
	private Long accountNumber;
	private String policyType;

	public Policy() {
		// TODO Auto-generated constructor stub
	}

	

	public Policy(Long policyNumber, Double policyPremium, Long accountNumber,
			String policyType) {
		super();
		this.policyNumber = policyNumber;
		this.policyPremium = policyPremium;
		this.accountNumber = accountNumber;
		this.policyType = policyType;
	}



	public String getPolicyType() {
		return policyType;
	}



	public void setPolicyType(String policyType) {
		this.policyType = policyType;
	}



	public Long getPolicyNumber() {
		return policyNumber;
	}

	public void setPolicyNumber(Long policyNumber) {
		this.policyNumber = policyNumber;
	}

	public Double getPolicyPremium() {
		return policyPremium;
	}

	public void setPolicyPremium(Double policyPremium) {
		this.policyPremium = policyPremium;
	}

	public Long getAccountNumber() {
		return accountNumber;
	}

	public void setAccountNumber(Long accountNumber) {
		this.accountNumber = accountNumber;
	}

	@Override
	public String toString() {
		return "PolicyNumber=" + policyNumber + ", PolicyPremium="
				+ policyPremium + ", AccountNumber=" + accountNumber;
	}

}
