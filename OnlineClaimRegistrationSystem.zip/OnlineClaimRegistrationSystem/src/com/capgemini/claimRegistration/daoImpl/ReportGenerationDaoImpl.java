package com.capgemini.claimRegistration.daoImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.Logger;

import com.capgemini.claimRegistration.dao.QueryMapper;
import com.capgemini.claimRegistration.dao.ReportGenerationDao;
import com.capgemini.claimRegistration.exception.ClaimException;
import com.capgemini.claimRegistration.jdbcUtility.JdbcUtility;
import com.capgemini.claimRegistration.model.Claim;

public class ReportGenerationDaoImpl implements ReportGenerationDao {
	static Logger logger = Logger.getLogger(ReportGenerationDaoImpl.class);


	Connection connection = null;
	PreparedStatement statement = null;
	ResultSet set = null;

	/**
	 * method name : getAllclaimReport  
	 * return type:  List<Claim> 
	 * author : Capgemini date : 06-11-2019
	 * description : This method returns the claimsReports to the user
	 */

	@Override
	public List<Claim> getAllclaimReport() throws ClaimException {
		logger.info("in ClaimDaoImpl  class");
		List<Claim> claim = new ArrayList<>();
		connection = JdbcUtility.getConnection();
		logger.info("connection object created");
		try {
			statement = connection.prepareStatement(QueryMapper.viewClaimReportQuery);
			logger.info("connection established..");
			
			set = statement.executeQuery();
			logger.info("resultset created");
					
			while (set.next()) {
				
				long claimNumber=set.getLong("CLAIM_NUMBER");
				String claimReason=set.getString("CLAIM_REASON");
				String claimType=set.getString("CLAIM_TYPE");
				long policyNumber=set.getLong("POLICY_NUMBER");
				Claim claim2=new Claim(claimNumber, claimReason, claimType, policyNumber);
		
				claim.add(claim2);

			}

		
		
		
		} catch (SQLException e) {
			logger.error(e.getMessage());

			throw new ClaimException("Sql Exception occured"+e);
		}

		return claim;
	}

}
